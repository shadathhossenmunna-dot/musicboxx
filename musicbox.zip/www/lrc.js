(function (root) {
  'use strict';
  var LEAD = /^((?:\s*\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+)\s*(.*)$/;
  var ONE = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
  var META = /^\s*\[[a-zA-Z#]+:[^\]]*\]\s*$/;
  var STRIP = /^(?:\s*\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+\s*/;

  function pad(n) { return String(n).padStart(2, '0'); }

  // Parse plain or LRC text. Returns { timed, lines: [{t, text}] }
  function parse(text) {
    var out = [];
    var timed = false;
    String(text || '').split(/\r?\n/).forEach(function (raw) {
      if (META.test(raw)) return;
      var m = LEAD.exec(raw);
      if (m) {
        timed = true;
        var body = m[2].trim();
        var s;
        ONE.lastIndex = 0;
        while ((s = ONE.exec(m[1])) !== null) {
          out.push({ t: (+s[1]) * 60 + (+s[2]) + (s[3] ? parseFloat('0.' + s[3]) : 0), text: body });
        }
      } else {
        out.push({ t: null, text: raw.trim() });
      }
    });
    if (timed) {
      return {
        timed: true,
        lines: out.filter(function (l) { return l.t !== null; }).sort(function (a, b) { return a.t - b.t; })
      };
    }
    return { timed: false, lines: out };
  }

  // "mm:ss.xx"
  function stampStr(t) {
    t = Math.max(0, t || 0);
    return pad(Math.floor(t / 60)) + ':' + pad(Math.floor(t % 60)) + '.' + pad(Math.floor((t * 100) % 100));
  }

  function stripStamps(text) {
    return String(text || '').split('\n').map(function (l) { return l.replace(STRIP, ''); }).join('\n');
  }

  // Put [mm:ss.xx] at the start of the line containing `pos`, return new value and caret (start of next line).
  function stampAt(value, pos, t) {
    var v = String(value || '');
    var ls = pos > 0 ? v.lastIndexOf('\n', pos - 1) + 1 : 0;
    var le = v.indexOf('\n', pos);
    if (le < 0) le = v.length;
    var line = v.slice(ls, le).replace(STRIP, '');
    var stamped = '[' + stampStr(t) + ']' + line;
    var next = v.slice(0, ls) + stamped + v.slice(le);
    return { value: next, caret: Math.min(next.length, ls + stamped.length + 1) };
  }

  var api = { parse: parse, stampStr: stampStr, stripStamps: stripStamps, stampAt: stampAt };
  root.LRC = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
