(() => {
  'use strict';

  /* ---------- helpers ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const native = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  const plug = (n) => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n]) || null;
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const safeName = (s) => String(s || 'song').replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);

  const ICONS = {
    play: '<path d="M8 5v14l11-7z"/>',
    pause: '<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>',
    next: '<path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>',
    prev: '<path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/>',
    shuffle: '<path d="M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z"/>',
    repeat: '<path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/>',
    down: '<path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/>',
    more: '<path d="M12 8a2 2 0 100-4 2 2 0 000 4zm0 2a2 2 0 100 4 2 2 0 000-4zm0 6a2 2 0 100 4 2 2 0 000-4z"/>',
    add: '<path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/>',
    note: '<path d="M12 3v10.55A4 4 0 1014 17V7h4V3h-6z"/>',
    back: '<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>',
    lyrics: '<path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h10v2H4z"/>'
  };
  const icon = (n, size = 24) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="currentColor" aria-hidden="true">${ICONS[n]}</svg>`;
  const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
  const artBg = (s) => { const h = hash(s || '') % 360; return `linear-gradient(135deg,hsl(${h} 62% 48%),hsl(${(h + 45) % 360} 62% 30%))`; };

  let toastTimer;
  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), 2400);
  }

  /* ---------- storage (IndexedDB) ---------- */
  let db;
  const openDB = () => new Promise((res, rej) => {
    const r = indexedDB.open('musicbox', 1);
    r.onupgradeneeded = () => {
      r.result.createObjectStore('songs', { keyPath: 'id' });
      r.result.createObjectStore('playlists', { keyPath: 'id' });
    };
    r.onsuccess = () => { db = r.result; res(); };
    r.onerror = () => rej(r.error);
  });
  const dbDo = (store, mode, fn) => new Promise((res, rej) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    t.oncomplete = () => res(req && req.result);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
  const dbAll = (store) => dbDo(store, 'readonly', (s) => s.getAll());
  const dbPut = (store, obj) => dbDo(store, 'readwrite', (s) => s.put(obj));
  const dbDel = (store, id) => dbDo(store, 'readwrite', (s) => s.delete(id));

  /* ---------- state ---------- */
  const S = {
    songs: [], playlists: [],
    tab: 'songs', plId: null, q: '',
    queue: [], idx: -1, shuffle: false, repeat: 'off',
    cur: null, url: null, drag: false,
    lyricsOpen: false, editing: false
  };
  const byId = (id) => S.songs.find((s) => s.id === id);
  const plById = (id) => S.playlists.find((p) => p.id === id);

  function visibleSongs() {
    let list = S.songs;
    if (S.tab === 'playlist') {
      const pl = plById(S.plId);
      list = pl ? pl.songIds.map(byId).filter(Boolean) : [];
    }
    const q = S.q.trim().toLowerCase();
    if (q) list = list.filter((s) => (s.title + ' ' + (s.artist || '')).toLowerCase().includes(q));
    return list;
  }

  /* ---------- list rendering ---------- */
  function render() {
    const inPl = S.tab === 'playlist';
    const pl = inPl ? plById(S.plId) : null;
    $('#title').textContent = inPl && pl ? pl.name : 'MusicBox';
    $('#backBtn').classList.toggle('hidden', !inPl);
    $('#tabs').classList.toggle('hidden', inPl);
    document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === S.tab));
    $('.search').classList.toggle('hidden', S.tab === 'playlists');

    const el = $('#list');
    if (S.tab === 'playlists') {
      let html = `<div class="row" data-newpl><div class="art" style="background:var(--bg3)">${icon('add')}</div><div class="meta"><div class="t">New playlist</div></div></div>`;
      html += S.playlists.map((p) => `
        <div class="row" data-pl="${p.id}">
          <div class="art" style="background:${artBg(p.name)}">${icon('note')}</div>
          <div class="meta"><div class="t">${esc(p.name)}</div><div class="a">${p.songIds.length} songs</div></div>
          <button class="more" data-plmore="${p.id}" aria-label="More">${icon('more')}</button>
        </div>`).join('');
      el.innerHTML = html;
      return;
    }

    const list = visibleSongs();
    if (!list.length) {
      el.innerHTML = S.songs.length && !inPl
        ? `<div class="empty"><b>No match</b>Try a different search.</div>`
        : `<div class="empty"><b>${inPl ? 'Playlist is empty' : 'No songs yet'}</b>${inPl ? 'Add songs from the ⋮ menu on any song.' : 'Add music from your phone to start listening.'}<br><button class="btn" data-add>Add songs</button></div>`;
      return;
    }
    const curId = S.cur && S.cur.id;
    el.innerHTML = list.map((s) => `
      <div class="row ${s.id === curId ? 'playing' : ''}" data-id="${s.id}">
        <div class="art" style="background:${artBg(s.title)}">${icon('note')}</div>
        <div class="meta"><div class="t">${esc(s.title)}</div><div class="a">${esc(s.artist || 'Unknown artist')}${s.duration ? ' · ' + fmt(s.duration) : ''}</div></div>
        <button class="more" data-more="${s.id}" aria-label="More">${icon('more')}</button>
      </div>`).join('');
  }

  /* ---------- modal helpers ---------- */
  function openModal(html) {
    const m = $('#modal');
    m.innerHTML = `<div class="m-card">${html}</div>`;
    m.classList.remove('hidden');
  }
  function closeModal() { const m = $('#modal'); m.classList.add('hidden'); m.innerHTML = ''; }
  const modalOpen = () => !$('#modal').classList.contains('hidden');

  function form(title, fields, okText, onOk) {
    openModal(`<div class="m-title">${esc(title)}</div>` +
      fields.map((f, i) => `<label>${esc(f.label)}</label><input data-f="${i}" value="${esc(f.value || '')}" autocomplete="off">`).join('') +
      `<div class="m-row"><button data-m="cancel">Cancel</button><button class="pri" data-m="ok">${esc(okText)}</button></div>`);
    const first = $('#modal input');
    if (first) { first.focus(); first.select(); }
    $('#modal').onclick = (e) => {
      const a = e.target.closest('[data-m]');
      if (e.target === $('#modal') || (a && a.dataset.m === 'cancel')) return closeModal();
      if (a && a.dataset.m === 'ok') {
        const vals = [...document.querySelectorAll('#modal input')].map((i) => i.value.trim());
        closeModal();
        onOk(vals);
      }
    };
  }

  function menu(title, items) {
    openModal(`<div class="m-title">${esc(title)}</div>` +
      items.map((it, i) => `<button class="${it.danger ? 'danger' : ''}" data-i="${i}">${esc(it.label)}</button>`).join(''));
    $('#modal').onclick = (e) => {
      if (e.target === $('#modal')) return closeModal();
      const b = e.target.closest('[data-i]');
      if (b) { closeModal(); items[+b.dataset.i].run(); }
    };
  }

  /* ---------- adding songs ---------- */
  const MIME = { mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', wav: 'audio/wav', ogg: 'audio/ogg', opus: 'audio/ogg', oga: 'audio/ogg' };
  function parseName(fn) {
    let n = fn.replace(/\.[^.]+$/, '').replace(/_/g, ' ').trim();
    n = n.replace(/^\d{1,3}[\s.\-_)]+(?=\D)/, '');
    const i = n.indexOf(' - ');
    if (i > 0) return { artist: n.slice(0, i).trim(), title: n.slice(i + 3).trim() || n };
    return { artist: '', title: n || fn };
  }
  function probeDuration(blob) {
    return new Promise((res) => {
      const a = new Audio();
      const u = URL.createObjectURL(blob);
      let done = false;
      const fin = (d) => { if (done) return; done = true; URL.revokeObjectURL(u); res(isFinite(d) ? d : 0); };
      a.preload = 'metadata';
      a.onloadedmetadata = () => fin(a.duration);
      a.onerror = () => fin(0);
      setTimeout(() => fin(0), 6000);
      a.src = u;
    });
  }
  async function addFiles(files) {
    const list = [...files];
    let added = 0, skipped = 0;
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      toast(`Adding ${i + 1}/${list.length}…`);
      const key = f.name + '|' + f.size;
      if (S.songs.some((s) => s.key === key)) { skipped++; continue; }
      const ext = (f.name.split('.').pop() || '').toLowerCase();
      const type = f.type || MIME[ext] || 'audio/mpeg';
      const blob = new Blob([f], { type });
      const meta = parseName(f.name);
      const song = { id: uid(), key, title: meta.title, artist: meta.artist, blob, type, size: f.size, added: Date.now(), duration: await probeDuration(blob), lyrics: '' };
      try { await dbPut('songs', song); S.songs.unshift(song); added++; }
      catch (e) { console.warn(e); toast('Could not save ' + f.name); }
    }
    render();
    toast(added ? `Added ${added} song${added > 1 ? 's' : ''}${skipped ? ` (${skipped} already there)` : ''}` : skipped ? 'Already in your library' : 'Nothing added');
  }

  /* ---------- player ---------- */
  const audio = new Audio();
  audio.preload = 'auto';

  async function loadAndPlay(song) {
    S.cur = song;
    if (S.url) URL.revokeObjectURL(S.url);
    S.url = URL.createObjectURL(song.blob);
    audio.src = S.url;
    S.editing = false;
    updateNowPlaying();
    renderLyrics();
    render();
    try { await audio.play(); } catch (e) { console.warn('play failed', e); }
  }
  function play(id, ids) {
    if (ids) S.queue = ids.slice();
    if (!S.queue.includes(id)) S.queue = [id];
    S.idx = S.queue.indexOf(id);
    const s = byId(id);
    if (s) loadAndPlay(s);
  }
  function next(auto) {
    if (!S.queue.length) return;
    if (auto && S.repeat === 'one') { audio.currentTime = 0; audio.play(); return; }
    let i;
    if (S.shuffle && S.queue.length > 1) {
      do { i = Math.floor(Math.random() * S.queue.length); } while (i === S.idx);
    } else {
      i = S.idx + 1;
      if (i >= S.queue.length) {
        if (S.repeat === 'all' || !auto) i = 0;
        else { audio.pause(); audio.currentTime = 0; return; }
      }
    }
    play(S.queue[i]);
  }
  function prev() {
    if (!S.queue.length) return;
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    const i = S.idx - 1 < 0 ? S.queue.length - 1 : S.idx - 1;
    play(S.queue[i]);
  }
  function toggle() {
    if (!S.cur) return;
    if (audio.paused) audio.play().catch(() => {}); else audio.pause();
  }

  function updateNowPlaying() {
    const s = S.cur;
    $('#mini').classList.toggle('hidden', !s);
    if (!s) return;
    $('#miniT').textContent = s.title;
    $('#miniA').textContent = s.artist || 'Unknown artist';
    $('#miniArt').style.background = artBg(s.title);
    $('#miniArt').innerHTML = icon('note');
    $('#bigArt').style.background = artBg(s.title);
    $('#bigArt').innerHTML = icon('note', 96);
    $('#npTitle').textContent = s.title;
    $('#npArtist').textContent = s.artist || 'Unknown artist';
    setPlayIcons();
    if ('mediaSession' in navigator) {
      try { navigator.mediaSession.metadata = new MediaMetadata({ title: s.title, artist: s.artist || '', album: 'MusicBox' }); } catch (e) { /* ignore */ }
    }
  }
  function setPlayIcons() {
    const n = audio.paused ? 'play' : 'pause';
    $('#miniPlay').innerHTML = icon(n);
    $('#bPlay').innerHTML = icon(n, 34);
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = audio.paused ? 'paused' : 'playing';
  }
  function updateProgress() {
    const d = audio.duration || (S.cur && S.cur.duration) || 0;
    const t = audio.currentTime || 0;
    $('#miniBar').style.width = d ? (t / d * 100) + '%' : '0';
    if (!S.drag) {
      $('#seek').max = d || 100;
      $('#seek').value = t;
      $('#tCur').textContent = fmt(t);
    }
    $('#tDur').textContent = fmt(d);
  }

  audio.addEventListener('play', setPlayIcons);
  audio.addEventListener('pause', setPlayIcons);
  audio.addEventListener('timeupdate', updateProgress);
  audio.addEventListener('ended', () => next(true));
  audio.addEventListener('loadedmetadata', () => {
    updateProgress();
    if (S.cur && !S.cur.duration && isFinite(audio.duration)) {
      S.cur.duration = audio.duration;
      dbPut('songs', S.cur).catch(() => {});
    }
  });
  audio.addEventListener('error', () => toast('Cannot play this file'));

  function initMediaSession() {
    if (!('mediaSession' in navigator)) return;
    const set = (a, f) => { try { navigator.mediaSession.setActionHandler(a, f); } catch (e) { /* unsupported */ } };
    set('play', () => audio.play());
    set('pause', () => audio.pause());
    set('previoustrack', prev);
    set('nexttrack', () => next(false));
    set('seekto', (d) => { if (d.seekTime != null) audio.currentTime = d.seekTime; });
    set('seekbackward', () => { audio.currentTime = Math.max(0, audio.currentTime - 10); });
    set('seekforward', () => { audio.currentTime = Math.min(audio.duration || 1e9, audio.currentTime + 10); });
  }

  /* ---------- full player ---------- */
  function openFull() {
    if (!S.cur) return;
    $('#full').classList.add('open');
    $('#full').setAttribute('aria-hidden', 'false');
    updateProgress();
  }
  function closeFull() {
    $('#full').classList.remove('open');
    $('#full').setAttribute('aria-hidden', 'true');
    if (S.editing && document.activeElement) document.activeElement.blur();
  }
  const fullOpen = () => $('#full').classList.contains('open');

  function showLyrics(on) {
    S.lyricsOpen = on;
    $('#lyr').classList.toggle('hidden', !on);
    $('#bigArt').classList.toggle('hidden', on);
    $('#lyricsBtn').classList.toggle('on', on);
    if (on) renderLyrics();
  }

  /* ---------- lyrics ---------- */
  let lyState = { timed: false, lines: [], active: -1, els: [] };

  function renderLyrics() {
    const box = $('#lyr');
    if (!S.cur) { box.innerHTML = ''; return; }
    if (S.editing) {
      box.innerHTML = `
        <textarea id="lyTa" spellcheck="false" placeholder="Paste or type lyrics here.&#10;&#10;For synced lyrics: play the song, put the cursor on a line and tap “Stamp line” at the right moment."></textarea>
        <div class="lyr-tools">
          <button data-ly="stamp">⏱ Stamp line</button>
          <button data-ly="clear">Clear stamps</button>
          <button data-ly="import">Import .lrc/.txt</button>
          <button data-ly="export">Export</button>
          <button data-ly="cancel">Cancel</button>
          <button data-ly="save" class="pri">Save</button>
        </div>`;
      $('#lyTa').value = S.cur.lyrics || '';
      return;
    }
    const parsed = LRC.parse(S.cur.lyrics);
    lyState = { timed: parsed.timed, lines: parsed.lines, active: -1, els: [] };
    let body;
    if (!S.cur.lyrics || !S.cur.lyrics.trim()) {
      body = `<div class="lyr-hint">No lyrics yet.<br>Tap “Edit lyrics” to paste or type them.</div>`;
    } else if (parsed.timed) {
      body = parsed.lines.map((l, i) => `<p data-t="${l.t}" data-i="${i}">${esc(l.text) || '♪'}</p>`).join('');
    } else {
      body = parsed.lines.map((l) => l.text ? `<p class="plain">${esc(l.text)}</p>` : `<p class="plain gap"></p>`).join('');
    }
    box.innerHTML = `<div class="lyr-bar"><button data-ly="edit">Edit lyrics</button></div><div class="lyr-body" id="lyBody">${body}</div>`;
    lyState.els = [...box.querySelectorAll('p[data-i]')];
    syncLyrics(true);
  }

  function syncLyrics(force) {
    if (!lyState.timed || !lyState.lines.length) return;
    const t = audio.currentTime + 0.12;
    let a = -1;
    for (let i = 0; i < lyState.lines.length; i++) { if (lyState.lines[i].t <= t) a = i; else break; }
    if (a === lyState.active && !force) return;
    lyState.active = a;
    lyState.els.forEach((p, i) => p.classList.toggle('on', i === a));
    const el = lyState.els[a];
    if (el) el.scrollIntoView({ block: 'center', behavior: force ? 'auto' : 'smooth' });
  }
  (function loop() {
    if (S.lyricsOpen && !S.editing && fullOpen() && !audio.paused) syncLyrics(false);
    requestAnimationFrame(loop);
  })();

  async function exportBlob(blob, name) {
    name = safeName(name);
    const FS = plug('Filesystem');
    const Share = plug('Share');
    if (native && FS && Share) {
      const b64 = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result).split(',')[1]);
        r.onerror = () => rej(r.error);
        r.readAsDataURL(blob);
      });
      const w = await FS.writeFile({ path: name, data: b64, directory: 'CACHE' });
      await Share.share({ title: name, url: w.uri, dialogTitle: 'Save or share' });
      return;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  function lyricsAction(act) {
    const ta = $('#lyTa');
    if (act === 'edit') { S.editing = true; renderLyrics(); return; }
    if (act === 'cancel') { S.editing = false; renderLyrics(); return; }
    if (act === 'save') {
      S.cur.lyrics = ta.value;
      dbPut('songs', S.cur).then(() => toast('Lyrics saved')).catch(() => toast('Could not save lyrics'));
      S.editing = false;
      renderLyrics();
      return;
    }
    if (!ta) return;
    if (act === 'stamp') {
      const r = LRC.stampAt(ta.value, ta.selectionStart, audio.currentTime);
      ta.value = r.value;
      ta.setSelectionRange(r.caret, r.caret);
      const lineIdx = ta.value.slice(0, r.caret).split('\n').length - 1;
      const lh = parseFloat(getComputedStyle(ta).lineHeight) || 26;
      ta.scrollTop = Math.max(0, lineIdx * lh - ta.clientHeight / 2);
    } else if (act === 'clear') {
      if (confirm('Remove all time stamps?')) ta.value = LRC.stripStamps(ta.value);
    } else if (act === 'import') {
      $('#lrcFile').click();
    } else if (act === 'export') {
      const timed = LRC.parse(ta.value).timed;
      exportBlob(new Blob([ta.value], { type: 'text/plain' }), `${S.cur.title}.${timed ? 'lrc' : 'txt'}`)
        .catch(() => toast('Export failed'));
    }
  }

  function openLyricsFor(id) {
    if (!S.cur || S.cur.id !== id) play(id, S.queue.includes(id) ? null : [id]);
    openFull();
    showLyrics(true);
    S.editing = true;
    renderLyrics();
  }

  /* ---------- menus ---------- */
  function songMenu(id) {
    const s = byId(id);
    if (!s) return;
    const items = [
      { label: 'Play next', run: () => {
        if (!S.cur) return play(id, [id]);
        S.queue.splice(S.idx + 1, 0, id);
        toast('Will play next');
      } },
      { label: 'Lyrics (add / edit)', run: () => openLyricsFor(id) },
      { label: 'Add to playlist', run: () => pickPlaylist(id) },
      { label: 'Edit title & artist', run: () => form('Edit song', [{ label: 'Title', value: s.title }, { label: 'Artist', value: s.artist }], 'Save', (v) => {
        s.title = v[0] || s.title; s.artist = v[1] || '';
        dbPut('songs', s).catch(() => {});
        render(); if (S.cur && S.cur.id === id) updateNowPlaying();
      }) },
      { label: 'Download / share file', run: () => {
        const ext = (s.type.split('/')[1] || 'mp3').replace('mpeg', 'mp3').replace('mp4', 'm4a');
        exportBlob(s.blob, `${s.artist ? s.artist + ' - ' : ''}${s.title}.${ext}`).catch(() => toast('Export failed'));
      } }
    ];
    if (S.tab === 'playlist') {
      items.push({ label: 'Remove from this playlist', run: () => {
        const pl = plById(S.plId);
        pl.songIds = pl.songIds.filter((x) => x !== id);
        dbPut('playlists', pl).catch(() => {}); render();
      } });
    }
    items.push({ label: 'Delete from library', danger: true, run: () => {
      if (!confirm(`Delete “${s.title}”?`)) return;
      if (S.cur && S.cur.id === id) { audio.pause(); audio.removeAttribute('src'); S.cur = null; closeFull(); updateNowPlaying(); }
      S.queue = S.queue.filter((x) => x !== id);
      S.songs = S.songs.filter((x) => x.id !== id);
      dbDel('songs', id).catch(() => {});
      S.playlists.forEach((p) => {
        if (p.songIds.includes(id)) { p.songIds = p.songIds.filter((x) => x !== id); dbPut('playlists', p).catch(() => {}); }
      });
      render();
    } });
    menu(s.title, items);
  }

  function newPlaylist(then) {
    form('New playlist', [{ label: 'Name', value: '' }], 'Create', (v) => {
      if (!v[0]) return;
      const p = { id: uid(), name: v[0], songIds: [] };
      S.playlists.push(p);
      dbPut('playlists', p).catch(() => {});
      render();
      if (then) then(p);
    });
  }
  function pickPlaylist(songId) {
    const items = S.playlists.map((p) => ({ label: p.name, run: () => {
      if (!p.songIds.includes(songId)) { p.songIds.push(songId); dbPut('playlists', p).catch(() => {}); }
      toast('Added to ' + p.name);
      render();
    } }));
    items.push({ label: '＋ New playlist…', run: () => newPlaylist((p) => { p.songIds.push(songId); dbPut('playlists', p).catch(() => {}); toast('Added to ' + p.name); render(); }) });
    menu('Add to playlist', items);
  }
  function playlistMenu(id) {
    const p = plById(id);
    menu(p.name, [
      { label: 'Rename', run: () => form('Rename playlist', [{ label: 'Name', value: p.name }], 'Save', (v) => { if (v[0]) { p.name = v[0]; dbPut('playlists', p).catch(() => {}); render(); } }) },
      { label: 'Delete playlist', danger: true, run: () => {
        if (!confirm(`Delete playlist “${p.name}”? Songs stay in your library.`)) return;
        S.playlists = S.playlists.filter((x) => x.id !== id);
        dbDel('playlists', id).catch(() => {}); render();
      } }
    ]);
  }

  /* ---------- events ---------- */
  function bind() {
    document.querySelectorAll('[data-icon]').forEach((b) => { b.innerHTML = icon(b.dataset.icon, b.id === 'bPlay' ? 34 : 24); });

    $('#addBtn').onclick = () => $('#file').click();
    $('#file').onchange = (e) => { const f = e.target.files; if (f && f.length) addFiles(f); e.target.value = ''; };
    $('#lrcFile').onchange = async (e) => {
      const f = e.target.files && e.target.files[0];
      e.target.value = '';
      const ta = $('#lyTa');
      if (f && ta) ta.value = await f.text();
    };

    $('#tabs').onclick = (e) => {
      const b = e.target.closest('[data-tab]');
      if (b) { S.tab = b.dataset.tab; render(); }
    };
    $('#backBtn').onclick = () => { S.tab = 'playlists'; S.plId = null; render(); };
    $('#q').oninput = (e) => { S.q = e.target.value; render(); };

    $('#list').onclick = (e) => {
      if (e.target.closest('[data-add]')) return $('#file').click();
      if (e.target.closest('[data-newpl]')) return newPlaylist();
      const pm = e.target.closest('[data-plmore]');
      if (pm) return playlistMenu(pm.dataset.plmore);
      const pr = e.target.closest('[data-pl]');
      if (pr) { S.tab = 'playlist'; S.plId = pr.dataset.pl; S.q = ''; $('#q').value = ''; return render(); }
      const m = e.target.closest('[data-more]');
      if (m) return songMenu(m.dataset.more);
      const row = e.target.closest('[data-id]');
      if (row) play(row.dataset.id, visibleSongs().map((s) => s.id));
    };

    $('#miniPlay').onclick = (e) => { e.stopPropagation(); toggle(); };
    $('#miniNext').onclick = (e) => { e.stopPropagation(); next(false); };
    $('#miniOpen').onclick = openFull;
    $('#closeFull').onclick = closeFull;
    $('#lyricsBtn').onclick = () => showLyrics(!S.lyricsOpen);
    $('#bPlay').onclick = toggle;
    $('#bNext').onclick = () => next(false);
    $('#bPrev').onclick = prev;
    $('#bShuffle').onclick = () => { S.shuffle = !S.shuffle; $('#bShuffle').classList.toggle('on', S.shuffle); };
    $('#bRepeat').onclick = () => {
      S.repeat = S.repeat === 'off' ? 'all' : S.repeat === 'all' ? 'one' : 'off';
      $('#bRepeat').classList.toggle('on', S.repeat !== 'off');
      $('#bRepeat').classList.toggle('one', S.repeat === 'one');
      toast('Repeat: ' + S.repeat);
    };

    const seek = $('#seek');
    seek.oninput = () => { S.drag = true; $('#tCur').textContent = fmt(+seek.value); };
    seek.onchange = () => { audio.currentTime = +seek.value; S.drag = false; };

    $('#lyr').onclick = (e) => {
      const b = e.target.closest('[data-ly]');
      if (b) return lyricsAction(b.dataset.ly);
      const p = e.target.closest('p[data-t]');
      if (p) { audio.currentTime = parseFloat(p.dataset.t); if (audio.paused) audio.play().catch(() => {}); }
    };

    // Android back button (Capacitor)
    const App = plug('App');
    if (native && App && App.addListener) {
      App.addListener('backButton', () => {
        if (modalOpen()) closeModal();
        else if (fullOpen()) closeFull();
        else if (S.tab === 'playlist') { S.tab = 'playlists'; S.plId = null; render(); }
        else if (App.minimizeApp) App.minimizeApp();
        else if (App.exitApp) App.exitApp();
      });
    }
  }

  /* ---------- start ---------- */
  async function init() {
    bind();
    initMediaSession();
    try {
      await openDB();
      S.songs = (await dbAll('songs')).sort((a, b) => b.added - a.added);
      S.playlists = await dbAll('playlists');
      if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    } catch (e) {
      console.error(e);
      toast('Storage unavailable — library will not be saved');
    }
    render();
    if (!native && 'serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  }
  init();
})();
