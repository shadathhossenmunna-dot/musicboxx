# MusicBox

Simple personal music player: apnar phone-er gaan add korun, playlist banan, lyrics likhun (plain ba synced .lrc), lock screen theke control korun. Dark UI, kono ad nei, kono account lage na.

## APK banano (free, ~5 minute, computer lage na)

1. github.com-e free account khulun, notun repository banan (Private rakhte paren).
2. Ei folder-er shob file upload korun (Add file, Upload files). `.github` folder-ta jeno jay, na gele **Add file, Create new file** diye `.github/workflows/build-apk.yml` naam dite hoy ar file-er content paste korte hoy.
3. **Actions** tab, **Build APK**, **Run workflow**.
4. 3-5 minute pore run-er page-e **Artifacts**-er niche `musicbox-apk` download korun, zip khule `app-debug.apk` phone-e install korun (Unknown sources allow korte hobe).

## Browser-e chalano (PWA)

`www` folder-e `python3 -m http.server` chalan, Chrome-e kholen, menu theke "Install app".

## Kivabe kaj kore

- Gaan phone-er storage-e (app-er nijosso database-e) thake. Internet lage na. App uninstall korle library muche jay.
- Gaan-er menu (⋮): Play next, Lyrics, Playlist, Edit info, Download/share, Delete.
- Synced lyrics: Lyrics tab, Edit lyrics, gaan chalan, line-e cursor rekhe "Stamp line" chapun. Ba `.lrc` file import korun.
- Cloud sync ekhon nei; eta porer step.
